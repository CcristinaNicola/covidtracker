package com.example.covidtracker;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;

public class ShowAll_Activity extends AppCompatActivity {
    private ListView listView;
    private ArrayList<Person> persons = new ArrayList<>();
    FirebaseHelper firebaseHelper;
    private Button show;
    DatabaseReference databaseReference;
    ArrayList<String> arrayList = new ArrayList<>();
    ArrayAdapter<String> arrayAdapter;
    private ArrayList<String> keyList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_all_layout);

        //SETUP DB
        databaseReference = FirebaseDatabase.getInstance().getReference("Person");
        firebaseHelper = new FirebaseHelper(databaseReference);

        listView = (ListView) findViewById(R.id.listView);
        show = (Button)findViewById(R.id.show);


        show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                arrayAdapter=new ArrayAdapter<String>(ShowAll_Activity.this,android.R.layout.simple_list_item_1,arrayList);
                listView.setAdapter(arrayAdapter);
                 editDatabase_add();
            }

        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                final String selectedItem = (String) parent.getItemAtPosition(position);
                AlertDialog.Builder builder = new AlertDialog.Builder(ShowAll_Activity.this);
                builder.setMessage("What do you wanna do?")
                        .setPositiveButton("UPDATE", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                            }
                        })
                        .setNegativeButton("DELETE", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                arrayAdapter.remove(selectedItem);
                                arrayAdapter.notifyDataSetChanged();
                                databaseReference.child(selectedItem).removeValue();
                            }
                        });
                // Create the AlertDialog object and return it
                AlertDialog alert =builder.create();
                alert.show();
                Toast.makeText(ShowAll_Activity.this,"Ceva",Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void editDatabase_add(){
        databaseReference.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                String value = snapshot.getValue(Person.class).toString();
                arrayList.add(value);
                arrayAdapter.notifyDataSetChanged();
                keyList.add(snapshot.getKey());
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) { }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {
                String value = snapshot.getValue(Person.class).toString();
                arrayList.remove(value);
                arrayAdapter.notifyDataSetChanged();
                keyList.remove(snapshot.getKey());
            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) { }

            @Override
            public void onCancelled(@NonNull DatabaseError error) { }
        });
    }

}

