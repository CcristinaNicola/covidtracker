package com.example.covidtracker;

import androidx.annotation.MainThread;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class Infected_Activity extends AppCompatActivity {

    private EditText nameTxt, ageTxt, contactTxt;
    private DatabaseReference databaseReference, rootRef, demoRef;

    private ValueEventListener databaseListener;

    private String currentName;


    public static final String Firebase_Server_URL = "https://covidtracker-f98b2-default-rtdb.firebaseio.com/";
    String nameHolder,ageHolder,contactHolder;
    private TextView showDataTextview;
    private Button confirm, back, search;
    FirebaseDatabase firebase;


//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.infected_layout);
//
//        name = (EditText) findViewById(R.id.name);
//        age = (EditText) findViewById(R.id.age);
//        contact = (EditText) findViewById(R.id.contact);
//        tStatus = (TextView) findViewById(R.id.tStatus);
//
//        FirebaseDatabase database = FirebaseDatabase.getInstance();
//        databaseReference = database.getReference();
//
////        back.setOnClickListener(new View.OnClickListener() {
////            @Override
////            public void onClick(View view) {
////                Intent intent = new Intent(view.getContext(), MainActivity.class);
////                view.getContext().startActivity(intent);}
////        });
//
////        confirm.setOnClickListener(new View.OnClickListener() {
////            @Override
////            public void onClick(View view) {
////                Person person = new Person(name.getText().toString(),Integer.parseInt(age.getText().toString()),contact.getText().toString());
////                int ages = Integer.parseInt(age.getText().toString());
////                databaseReference.child("Person").child("Ion").child("Age").setValue(ages).addOnCompleteListener(new OnCompleteListener<Void>() {
////                    @Override
////                    public void onComplete(@NonNull Task<Void> task) {
////                        Log.d("drondu", String.valueOf(task.isSuccessful()));
////                    }
////                });
////            }
////        });
////    }
//
//
////        // Database reference pointing to root of database
////        rootRef = FirebaseDatabase.getInstance().getReference();
////
////        // Database reference pointing to demo node
////        demoRef = rootRef.child("Person");
////
////        confirm = (Button) findViewById(R.id.confirm);
////        confirm.setOnClickListener(new View.OnClickListener() {
////            @Override
////            public void onClick(View v) {
////                String value = contact.getText().toString();
////
////                // Push creates a unique id in database
////                demoRef.setValue(value);
////            }
////        });
////
//   }
//
//
//    //_______________________________________________________________________________________________________________________________
//
//    public void clicked(View view) {
//        switch (view.getId()) {
//            case R.id.search: {
//                if (!name.getText().toString().isEmpty()) {
//                    // save text to lower case (all our months are stored online in lower case)
//                    currentName = name.getText().toString();
//
//                    tStatus.setText("Searching ...");
//                    createNewDBListener();
//                } else {
//                    Toast.makeText(this, "Search field may not be empty", Toast.LENGTH_SHORT).show();
//                }
//                break;
//            }
//            case R.id.confirm:
//            {
//                databaseReference.child("Person").child(currentName).setValue(new Person(currentName, Integer.parseInt(age.getText().toString()), contact.getText().toString())).addOnCompleteListener(new OnCompleteListener() {
//                    @Override
//                    public void onComplete(@NonNull Task task) {
//                        Log.d("drondu", String.valueOf(task.isSuccessful()));
//                    }
//                });
//            }
//            break;
//
//            case R.id.back: {
//                Intent intent = new Intent(view.getContext(), MainActivity.class);
//                view.getContext().startActivity(intent);
//                break;
//            }
//        }
//    }
//
//    private void createNewDBListener() {
//        // remove previous databaseListener
//        if (databaseReference != null && currentName != null && databaseListener != null)
//            databaseReference.child("Person").child(currentName).removeEventListener(databaseListener);
//
//        databaseListener = new ValueEventListener() {
//            @Override
//            public void onDataChange(DataSnapshot dataSnapshot) {
//                // This method is called once with the initial value and again
//                // whenever data at this location is updated.
//                Person person = dataSnapshot.getValue(Person.class);
//                System.out.println(person);
//
//                // explicit mapping of month name from entry key
//                assert person != null;
//                person.name = dataSnapshot.getKey();
//
//                age.setText(String.valueOf(person.getAge()));
//                contact.setText(String.valueOf(person.getContact()));
//                tStatus.setText("Found entry for " + currentName);
//            }
//
//            @Override
//            public void onCancelled(DatabaseError error) {
//                Toast.makeText(Infected_Activity.this, "Search field may not be empty", Toast.LENGTH_SHORT).show();
//            }
//        };
//
//        // set new databaseListener
//        databaseReference.child("Person").child(currentName).addValueEventListener(databaseListener);
//
//    }

    //-----------------------------------------------------------------------
    FirebaseHelper firebaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.infected_layout);
        Spinner sp = findViewById(R.id.sp);

        //SETUP DB
        databaseReference = FirebaseDatabase.getInstance().getReference();
        firebaseHelper = new FirebaseHelper(databaseReference);

        sp.setAdapter(new ArrayAdapter<Object>(this, android.R.layout.simple_list_item_1, firebaseHelper.retrieve()));


        nameTxt = (EditText) findViewById(R.id.name);
        ageTxt = (EditText) findViewById(R.id.age);
        contactTxt = (EditText) findViewById(R.id.contact);
        confirm = (Button) findViewById(R.id.confirm);

        //SAVE
        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //GET DATA
                String name = nameTxt.getText().toString();
                int age = Integer.parseInt(ageTxt.getText().toString());
                String contact = contactTxt.getText().toString();

                //SET DATA
                Person p = new Person();
                p.setName(name);
                p.setAge(age);
                p.setContact(contact);
                //SAVE
                if (name != null && name.length() > 0 && age != 0 && contact != null && contact.length() > 0 ) {
                    if (firebaseHelper.save(p)) {
                        nameTxt.setText("");
                        ageTxt.setText("");
                        contactTxt.setText("");
                    }

                } else {
                    Toast.makeText(Infected_Activity.this, "Name empty", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }
}