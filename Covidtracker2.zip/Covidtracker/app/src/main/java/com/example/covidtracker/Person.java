package com.example.covidtracker;

public class Person {

    public String name;
    public int age;
    public String contact;

    public Person() {
        // Default constructor required for calls to DataSnapshot.getValue(User.class)
    }

    public Person(String name, int age,String contact) {
        this.name = name;
        this.age = age;
        this.contact=contact;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public int getAge() {
        return age;
    }

    public String getContact() {
        return contact;
    }
}
