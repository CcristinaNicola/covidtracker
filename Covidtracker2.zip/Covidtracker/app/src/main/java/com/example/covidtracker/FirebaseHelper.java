package com.example.covidtracker;

import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseException;
import com.google.firebase.database.DatabaseReference;

import java.util.ArrayList;

public class FirebaseHelper {
    DatabaseReference db;
    Boolean saved = null;

    public FirebaseHelper(DatabaseReference db) {
        this.db = db;
    }

    //SAVE

    public Boolean save(Person person){
        if(person == null){
            saved = false;
        }else{
            try{
                db.child("Person").push().setValue(person);
                saved = true;
            }catch (DatabaseException e){
                e.printStackTrace();
                saved = false;
            }
        }
        return saved;
    }

    //READ
    public ArrayList<Object> retrieve(){

        final ArrayList<Object> person = new ArrayList<>();

        db.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                fetchData(dataSnapshot,person);
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                fetchData(dataSnapshot,person);
            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        return person;
    }

    private  void fetchData(DataSnapshot snapshot,ArrayList<Object> person){
       // person.clear();
        for(DataSnapshot ds : snapshot.getChildren()){
            Person pers = (Person) ds.child("Person").getValue(Person.class) ;
            assert pers != null;
            try {
                String name = pers.getName();
                Log.d("ceva  ",name);
                int age = pers.getAge();
                String contact = pers.getContact();

                person.add(name);
                person.add(age);
                person.add(contact);
            }catch(Exception e){
                System.out.println(e);
            }


        }
    }
}
