package com.example.covidtracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Cured_Activity extends AppCompatActivity {

    private EditText nameTxt, ageTxt, contactTxt;
    private Button save;
    private FirebaseHelper firebaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cured_layout);

        save = (Button) findViewById(R.id.confirm);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //GET DATA
                String name = nameTxt.getText().toString();
                int age = Integer.parseInt(ageTxt.getText().toString());
                String contact = contactTxt.getText().toString();

                //SET DATA
                Person p = new Person();
                p.setName(name);
                p.setAge(age);
                p.setContact(contact);
                //SAVE
                if (name != null && name.length() > 0 && age != 0 && contact != null && contact.length() > 0 ) {
                    if (firebaseHelper.delete(p)) {
                        nameTxt.setText("");
                        ageTxt.setText("");
                        contactTxt.setText("");
                    }

                } else {
                    Toast.makeText(Cured_Activity.this, "Cannot be empty", Toast.LENGTH_SHORT).show();
                }

            }
        });





    }
}